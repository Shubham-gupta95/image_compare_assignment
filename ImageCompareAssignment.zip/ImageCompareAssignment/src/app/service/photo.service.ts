import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { ImageRes } from '../Model/Image.model';

@Injectable({
  providedIn: 'root'
})
export class PhotoService {

  constructor(private http: HttpClient) { }

  getImageData(): Observable<Array<ImageRes>> {
    return this.http.get<Array<ImageRes>>('https://jsonplaceholder.typicode.com/photos')
  }
}
