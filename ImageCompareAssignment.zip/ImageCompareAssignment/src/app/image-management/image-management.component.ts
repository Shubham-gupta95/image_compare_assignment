import { Component, OnInit } from '@angular/core';
import { ImageRes2 } from '../Model/Image.model';
import { PhotoService } from '../service/photo.service';

@Component({
  selector: 'app-image-management',
  templateUrl: './image-management.component.html',
  styleUrls: ['./image-management.component.css']
})
export class ImageManagementComponent implements OnInit {
  imageRes: Array<ImageRes2> = []

  constructor(private imageService: PhotoService) { }

  ngOnInit(): void {
    this.imageService.getImageData().subscribe(resp => {
      this.imageRes = resp.map(image => {
        const img = Object.assign({}, image) as ImageRes2
        img.isSelected = false
        return img
      })
    })
  }

  setSelectedImage(image: ImageRes2) {
    this.imageRes.forEach(i => {
      if (i.id == image.id) {
        i.isSelected = image.isSelected
      }
    })
  }

}
