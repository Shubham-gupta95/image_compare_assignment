export type ImageRes = {
    albumId: number,
    id: number,
    thumbnailUrl: string,
    title: string,
    url: string
}

export type ImageRes2 = {
    albumId: number,
    id: number,
    thumbnailUrl: string,
    title: string,
    url: string,
    isSelected: boolean
}