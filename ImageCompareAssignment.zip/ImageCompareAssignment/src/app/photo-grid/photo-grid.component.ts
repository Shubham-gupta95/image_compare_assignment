import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';
import { ImageRes2 } from '../Model/Image.model';

@Component({
  selector: 'app-photo-grid',
  templateUrl: './photo-grid.component.html',
  styleUrls: ['./photo-grid.component.css']
})
export class PhotoGridComponent implements OnInit {
  @Input() image!: ImageRes2
  @Output() selectedImage = new EventEmitter<ImageRes2>()
  constructor() { }

  ngOnInit(): void {
  }

  compareImage(image: ImageRes2) {
    this.image.isSelected = !this.image.isSelected
    this.selectedImage.emit(image)
  }

}
